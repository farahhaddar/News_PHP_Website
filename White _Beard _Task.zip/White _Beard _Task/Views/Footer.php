<div class="footer">
   <div class="social">
     <a href='https://www.facebook.com/WhiteBeardME'>
    <i style="font-size:24px" class="fab fa-facebook-square"></i>
      Facebook
     </a>
   </div>
  <div>
        &copy;
        <span id="copyright">
            <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script>
        </span>
        White Beard Task
   </div>
</div>
