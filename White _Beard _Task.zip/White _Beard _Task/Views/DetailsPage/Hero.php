<div >
   <img class="heroimg" style="height:400px;width: 100%;" src="<?php echo $single_article['cover_image'] ?>">
</div>