<div class="title"><?php echo $single_article['title'] ?></div>
<div >
    <span class="authorinfo" >By</span>
    <span class="auther" > <?php echo $single_article['author'] ?> </span>
    <span class="authorinfoBar"></span>
    <span class="authorinfo"  > <?php echo $single_article['published_on'] ?></span>
</div>

<div class="fullContent"><?php echo $single_article['full_content'] ?></div>