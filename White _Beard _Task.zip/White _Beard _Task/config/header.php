<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="News Website that exclusivly prensent the most recent and trend news"/>
<meta name="keywords" content="News, Most Recent News, TopView">
<link rel="stylesheet" href="CSS/styles.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<?php include_once "analatics.php"?>
