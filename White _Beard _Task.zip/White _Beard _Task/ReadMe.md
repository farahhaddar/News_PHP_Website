# To run this project:
1- Make a new database and import the .sql file in the Database dir into it.

2- change your credentials in Connection.php file in src/Connection.

3- Run the project on any port.


#My Notes:

1- It was my first time to use jquery and ajax call in vanilla Js . It took me some time to understand how it works. But it turned out to be so simple and eassy.

2- Google Analatics:
I managed to get the project linked to a fake account but I didn't go deep into what does it offer.

3- The Share Buttons:
Facebook is not allowing this feauture since the app is under development.

That is all from my part hope you like my work :)


